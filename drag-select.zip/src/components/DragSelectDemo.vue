<template>
    <div class="mx-auto max-w-6xl p-5">
        <h1 class="text-2xl font-bold mb-6 text-center">VLAN管理</h1>
        <div class="flex gap-6">
            <!-- 左侧隔离区 -->
            <div class="w-1/2">
                <h2 class="text-xl font-bold mb-4">隔离区</h2>
                <div class="vlan-container bg-red-50 dark:bg-red-900/20">
                    <SelectionArea ref="isolatedSelectionArea" class="selection-container" :options="{ selectables: '.isolated-selectable' }"
                        :onMove="onMoveIsolated" :onStart="onStart">
                        <a-list class="vlan-list">
                            <VueDraggable v-model="isolatedVlans" class="min-h-[500px]" group="vlans" :sort="false"
                                item-key="id" @start="dragStart" @end="dragEnd" ghostClass="ghost-item">
                                <a-list-item v-for="element in isolatedVlans" :key="element.id"
                                    class="isolated-selectable"
                                    :class="{ 'selected': selectedIsolated.has(element.id) }" :data-key="element.id">
                                    <a-list-item-meta>
                                        <template #title>{{ element.name }}</template>
                                        <template #description>VLAN ID: {{ element.id }}</template>
                                    </a-list-item-meta>
                                </a-list-item>
                            </VueDraggable>
                        </a-list>
                    </SelectionArea>
                </div>
            </div>

            <!-- 右侧联通区 -->
            <div class="w-1/2">
                <h2 class="text-xl font-bold mb-4">联通区</h2>
                <div class="vlan-container bg-green-50 dark:bg-green-900/20">
                    <SelectionArea ref="connectedSelectionArea" class="selection-container" :options="{ selectables: '.connected-selectable' }"
                        :onMove="onMoveConnected" :onStart="onStart">
                        <a-list class="vlan-list">
                            <VueDraggable v-model="connectedVlans" class="min-h-[500px]" group="vlans" :sort="false"
                                item-key="id" @start="dragStart" @end="dragEnd" ghostClass="ghost-item">
                                <a-list-item v-for="element in connectedVlans" :key="element.id"
                                    class="connected-selectable"
                                    :class="{ 'selected': selectedConnected.has(element.id) }" :data-key="element.id">
                                    <a-list-item-meta>
                                        <template #title>{{ element.name }}</template>
                                        <template #description>VLAN ID: {{ element.id }}</template>
                                    </a-list-item-meta>
                                </a-list-item>
                            </VueDraggable>
                        </a-list>
                    </SelectionArea>
                </div>
            </div>
        </div>

        <div class="mt-6">
            <div v-if="selectedIsolated.size || selectedConnected.size"
                class="p-4 bg-gray-100 dark:bg-gray-800 rounded">
                <div v-if="selectedIsolated.size">
                    已在隔离区选择 {{ selectedIsolated.size }} 项VLAN
                </div>
                <div v-if="selectedConnected.size">
                    已在联通区选择 {{ selectedConnected.size }} 项VLAN
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { VueDraggable } from 'vue-draggable-plus';
import { SelectionArea, SelectionEvent } from '@viselect/vue';

// VLAN数据类型定义
interface Vlan {
    id: number;
    name: string;
}

// 生成测试数据
const generateVlans = (count: number): Vlan[] => {
    return Array.from({ length: count }, (_, i) => ({
        id: i + 1,
        name: `VLAN ${i + 1}`,
    }));
};

// 状态管理
const isolatedVlans = ref<Vlan[]>([]);
const connectedVlans = ref<Vlan[]>([]);
const selectedIsolated = reactive<Set<number>>(new Set());
const selectedConnected = reactive<Set<number>>(new Set());
const isDragging = ref(false);
const draggedItem = ref<{ id: number, fromZone: 'isolated' | 'connected' } | null>(null);

// 添加对SelectionArea组件的引用
const isolatedSelectionArea = ref<InstanceType<typeof SelectionArea> | null>(null);
const connectedSelectionArea = ref<InstanceType<typeof SelectionArea> | null>(null);

// 初始化数据
onMounted(() => {
    // 初始时所有VLAN都在联通区
    connectedVlans.value = generateVlans(500);
});

// 框选处理函数
const extractIds = (els: Element[]): number[] => {
    return els.map(v => Number(v.getAttribute('data-key')))
        .filter(Boolean);
};

const onStart = ({ event, selection }: SelectionEvent) => {
    // 如果正在拖拽中，不进行框选操作
    if (isDragging.value) return;
    
    if (!event?.ctrlKey && !event?.metaKey) {
        selection.clearSelection();
        selectedIsolated.clear();
        selectedConnected.clear();
    }
};

const onMoveIsolated = ({ store: { changed: { added, removed } } }: SelectionEvent) => {
    // 如果正在拖拽中，不处理选中变更
    if (isDragging.value) return;
    
    extractIds(added).forEach(id => selectedIsolated.add(id));
    extractIds(removed).forEach(id => selectedIsolated.delete(id));
};

const onMoveConnected = ({ store: { changed: { added, removed } } }: SelectionEvent) => {
    // 如果正在拖拽中，不处理选中变更
    if (isDragging.value) return;
    
    extractIds(added).forEach(id => selectedConnected.add(id));
    extractIds(removed).forEach(id => selectedConnected.delete(id));
};

// 拖拽处理
const dragStart = (e: any) => {
    isDragging.value = true;
    
    // 获取被拖拽元素的ID和来源区域
    const draggedElement = e.item;
    const id = Number(draggedElement.getAttribute('data-key'));
    
    // 记录当前拖拽的元素信息
    if (isolatedVlans.value.some(item => item.id === id)) {
        draggedItem.value = { id, fromZone: 'isolated' };
    } else {
        draggedItem.value = { id, fromZone: 'connected' };
    }
};

const dragEnd = (e: any) => {
    isDragging.value = false;
    
    if (!draggedItem.value) return;
    
    const { id, fromZone } = draggedItem.value;
    
    // 检查元素是否真的被拖到了不同的区域
    const fromContainer = e.from;
    const toContainer = e.to;
    
    // 如果源容器和目标容器相同，则不执行移动操作
    if (fromContainer === toContainer) {
        // 清除视觉选择效果
        isolatedSelectionArea.value?.selection?.cancel();
        isolatedSelectionArea.value?.selection?.clearSelection();
        connectedSelectionArea.value?.selection?.cancel();
        connectedSelectionArea.value?.selection?.clearSelection();
        return
    }
    
    // 如果拖拽的是选中集合中的元素，则移动所有选中元素
    if ((fromZone === 'isolated' && selectedIsolated.has(id)) || 
        (fromZone === 'connected' && selectedConnected.has(id))) {
        
        if (fromZone === 'isolated') {
            // 从隔离区移动选中元素到联通区
            const itemsToMove = isolatedVlans.value.filter(item => selectedIsolated.has(item.id));
            connectedVlans.value = [...connectedVlans.value, ...itemsToMove]; // 确保添加到末尾
            isolatedVlans.value = isolatedVlans.value.filter(item => !selectedIsolated.has(item.id));
        } else {
            // 从联通区移动选中元素到隔离区
            const itemsToMove = connectedVlans.value.filter(item => selectedConnected.has(item.id));
            isolatedVlans.value = [...isolatedVlans.value, ...itemsToMove]; // 确保添加到末尾
            connectedVlans.value = connectedVlans.value.filter(item => !selectedConnected.has(item.id));
        }
    }
    
    // 重置状态
    draggedItem.value = null;
    selectedIsolated.clear();
    selectedConnected.clear();
    
    // 清除视觉选择效果
    isolatedSelectionArea.value?.selection?.cancel();
    isolatedSelectionArea.value?.selection?.clearSelection();
    connectedSelectionArea.value?.selection?.cancel();
    connectedSelectionArea.value?.selection?.clearSelection();
};
</script>

<style scoped lang="scss">
.vlan-container {
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    height: 600px;
    overflow-y: auto;
}

.selection-container {
    height: 100%;
    position: relative;
}

.vlan-list {
    width: 100%;
}

// 选中状态样式
.isolated-selectable.selected {
    background: rgba(255, 77, 79, 0.2);
    border: 1px solid rgba(255, 77, 79, 0.4);
    box-shadow: 0 0 0 1px rgba(255, 77, 79, 0.1);
    border-radius: 4px;
}

.connected-selectable.selected {
    background: rgba(82, 196, 26, 0.2);
    border: 1px solid rgba(82, 196, 26, 0.4);
    box-shadow: 0 0 0 1px rgba(82, 196, 26, 0.1);
    border-radius: 4px;
}

:deep(.ant-list-item) {
    cursor: move;
    margin-bottom: 8px;
    transition: all 0.2s ease;
    border-radius: 4px;
    background-color: #ffffff;
    border: 1px solid #f0f0f0;
    
    @media (prefers-color-scheme: dark) {
        background-color: #1f1f1f;
        border: 1px solid #303030;
    }
    
    &:hover {
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        transform: translateY(-1px);
        background-color: #fafafa;
        
        @media (prefers-color-scheme: dark) {
            background-color: #2a2a2a;
        }
    }
}

:deep(.ant-list-item-meta-title) {
    margin-bottom: 4px !important;
    font-weight: 500;
}

// 拖拽中的ghost元素样式
.ghost-item {
    opacity: 0.5;
    background: #c8ebfb;
    border: 1px dashed #2196f3;
}
</style>

<style lang="scss">
.selection-area {
    background: rgba(46, 115, 252, 0.11);
    border: 1px solid rgba(98, 155, 255, 0.85);
    border-radius: 0.15em;
    z-index: 10;
}
</style>