import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { AntDesignVueResolver } from 'unplugin-vue-components/resolvers';

export default defineConfig({
  plugins: [
    vue(),
    AutoImport({
      // 自动导入Vue相关函数
      imports: ['vue'],
      // 可以选择auto-import.d.ts生成的位置，使IDE获得类型提示
      dts: 'src/auto-import.d.ts'
    }),
    Components({
      resolvers: [
        AntDesignVueResolver({
          importStyle: false, // 不导入样式，使用全局导入的样式
        }),
      ],
      dts: 'src/components.d.ts',
    }),
  ],
});
